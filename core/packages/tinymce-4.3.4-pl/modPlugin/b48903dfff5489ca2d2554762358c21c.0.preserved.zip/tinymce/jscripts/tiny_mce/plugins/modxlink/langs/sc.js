tinyMCE.addI18n('sc.modxlink',{
    link_desc:"Insert/edit link"
});